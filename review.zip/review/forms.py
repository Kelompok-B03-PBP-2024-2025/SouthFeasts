from django import forms
from .models import ReviewEntry

class ReviewForm(forms.ModelForm):
    class Meta:
        model = ReviewEntry
        fields = ['rating', 'review_text', 'image']  # Add 'image' field here
        widgets = {
            'rating': forms.RadioSelect(choices=[(i, f'{i} Stars') for i in range(1, 6)]),
            'review_text': forms.Textarea(attrs={'rows': 4, 'cols': 40}),
        }

    # Override init to include enctype for file upload
    def __init__(self, *args, **kwargs):
        super(ReviewForm, self).__init__(*args, **kwargs)
        self.fields['image'].widget.attrs.update({'accept': 'image/*'})
